import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl,} from '@angular/forms';
import { AddstudentService } from 'src/app/addstudent.service';

@Component({
  selector: 'app-addstudent',
  templateUrl: './addstudent.component.html',
  styleUrls: ['./addstudent.component.css']
})
export class AddstudentComponent implements OnInit {

  constructor(private _addstudent: AddstudentService) {}
  addstudent = new FormGroup({
    name: new FormControl(''),
    tech: new FormControl(''),
  });

  onSubmit(){
    console.log(this.addstudent.value);
    this._addstudent.register(this.addstudent.value)
     .subscribe(
      response => console.log('Added', response)
    ); 
  }

  ngOnInit() {
  }

}
