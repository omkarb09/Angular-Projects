import { Component, OnInit } from '@angular/core';
import { CurrencyConversionService } from '../currency-conversion.service';
import { FormGroup, FormControl } from '@angular/forms'; 

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {

  public amount ;


  constructor(private _currencyConversionService : CurrencyConversionService) { }

  currencyConversion = new FormGroup({
    from : new FormControl(''),
    to : new FormControl(''),
    amount : new FormControl('')
  });

  ngOnInit() {
    // this._currencyConversionService.getConvertedAmount()
    //   .subscribe(data=>this.amount=data);
  }
  onSubmit(){
     //console.log(this.currencyConversion.value);
     this._currencyConversionService.register(this.currencyConversion.value)
     .subscribe(data=>this.amount=data.totalCalculatedAmount);
     
  }

}
