import { Component } from '@angular/core';
import { EmployeesService } from './employees.service';


@Component({
  selector: 'app-root',
  template: `
 
  <h1>Employee details</h1>
  <ul *ngFor="let detail of employees">
  <li> {{detail.name}} </li>
  
  </ul>
  <app-test></app-test>
 
  `,
  styles:[`
  
  `]
})
export class AppComponent {

 employees=[];
 constructor(private _employeeservice: EmployeesService){}
ngOnInit()
{
  this._employeeservice.getEmployee().subscribe(data => this.employees = data);
}
}
