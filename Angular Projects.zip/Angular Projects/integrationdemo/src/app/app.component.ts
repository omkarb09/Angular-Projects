import { Component } from '@angular/core';
import { HttpClient, HttpDownloadProgressEvent } from '@angular/common/http';
import { error } from 'util';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Integration Demo';

  myresponse: any;

  readonly APP_URL = 'http://localhost:8080/RestDemo/student';

  constructor(private _http: HttpClient)
  {

  }

  getAllStudents()
  {
    this._http.get(this.APP_URL).subscribe(
      data=>{
        this.myresponse=data;
      },
      error=>{
        console.log('Error occured',error);
      }
    );
  }
}
