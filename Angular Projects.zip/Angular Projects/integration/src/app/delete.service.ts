import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DeleteService {

  _url='http://localhost:8080/RestDemo/deleteStudent/';

  constructor(private _http: HttpClient) { }


  

  register(userData: Object) {
   return this._http.delete<any>(this._url+Object.values(userData)); 
  }


}
