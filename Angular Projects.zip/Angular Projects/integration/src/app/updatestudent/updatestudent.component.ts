import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl} from '@angular/forms';
import { UpdatestudentService } from 'src/app/updatestudent.service';

@Component({
  selector: 'app-updatestudent',
  templateUrl: './updatestudent.component.html',
  styleUrls: ['./updatestudent.component.css']
})
export class UpdatestudentComponent implements OnInit {

  constructor(private _updatestudent: UpdatestudentService) {}
  updatestudent = new FormGroup({
    id: new FormControl(''),
    name: new FormControl(''),
    tech: new FormControl(''),
  });

  onSubmit(){
    console.log(this.updatestudent.value);
    this._updatestudent.register(this.updatestudent.value)
     .subscribe(
      response => console.log('Updated', response)
    ); 
  }

  ngOnInit() {
  }

}
