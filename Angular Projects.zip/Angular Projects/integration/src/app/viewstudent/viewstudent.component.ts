import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-viewstudent',
  templateUrl: './viewstudent.component.html',
  styleUrls: ['./viewstudent.component.css']
})
export class ViewstudentComponent  {

  myresponse: any;

  readonly APP_URL = 'http://localhost:8080/RestDemo/student';

  constructor(private _http: HttpClient)
  {

  }

  getAllStudents()
  {
    this._http.get(this.APP_URL).subscribe(
      data=>{
        this.myresponse=data;
      },
      error=>{
        console.log('Error occured',error);
      }
    );
  }
}



