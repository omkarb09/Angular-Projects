import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-test5',
  templateUrl: './test5.component.html',
  styleUrls: ['./test5.component.css']
})
export class Test5Component implements OnInit {

  public employee = [];
  constructor(private _employeeService: EmployeeService) { }

  ngOnInit() {
  this._employeeService.getEmployees()
  .subscribe(data => this.employee = data);
  }

}
