import { TestBed } from '@angular/core/testing';

import { UpdatestudentService } from './updatestudent.service';

describe('UpdatestudentService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UpdatestudentService = TestBed.get(UpdatestudentService);
    expect(service).toBeTruthy();
  });
});
