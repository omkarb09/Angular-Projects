import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-department-list',
  template: `
    <p>
      department-list!
    </p>
    <ul class="items">
    <li (click)="onSelect(department)" *ngFor="let department of departments">
    <span class="badge">{{department.id}}</span>  {{department.name}}
    </li>
    </ul>

    <button (click)="onSelect(department)" *ngFor="let department of departments">{{department.id}} {{department.name}}</button>
  `,
  styles: []
})
export class DepartmentListComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }

  departments=[
  {"id": 1, "name": "ML"},
  {"id": 2, "name": "Android"},
  {"id": 3, "name": "Ai"}
  ]
  onSelect(department){
    this.router.navigate(['/departments', department.id]);
  }

}
