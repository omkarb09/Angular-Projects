import { Component, OnInit } from '@angular/core';
import { DeleteService } from 'src/app/delete.service';
import { FormGroup, FormControl} from '@angular/forms';
import { analyzeAndValidateNgModules } from '@angular/compiler';

@Component({
  selector: 'app-deletestudent',
  templateUrl: './deletestudent.component.html',
  styleUrls: ['./deletestudent.component.css']
})
export class DeletestudentComponent implements OnInit {
   hi: any;

  constructor(private _deletestudent: DeleteService) { }
  deletestudent = new FormGroup({
    id: new FormControl('')
  });

  onSubmit(){
    
    this._deletestudent.register(this.deletestudent.value)
     .subscribe(
        data=>{
          this.hi=data;
        },
        error=>{
          console.log('Error occured',error);
        }
      );
  }

  ngOnInit() {
  }

}
