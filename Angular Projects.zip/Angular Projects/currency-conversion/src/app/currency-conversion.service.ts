import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { ICurrency } from './currency';

@Injectable({
  providedIn: 'root'
})
export class CurrencyConversionService {

  //private _url : string = "http://localhost:8100/currency-converter-feign/from/AUD/to/INR/quantity/10000";
  dataurl: any;
  constructor(private http: HttpClient) { }

  register(data:Object):Observable<ICurrency>
  {
    this.dataurl=data;
    console.log(data);
    return this.http.get<ICurrency>('http://localhost:8100/currency-converter-feign/from/'+this.dataurl.from+'/to/'+this.dataurl.to+'/quantity/'+this.dataurl.amount);
           // .subscribe(response => console.log(response));
  }
}
