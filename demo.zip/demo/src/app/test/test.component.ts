import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
  isHidden=true;

  text ='';

  constructor() { }

  ngOnInit() {
  }

  onClick()
  {
    if(this.isHidden==true)
    this.isHidden=false;

    else
    this.isHidden=true;
  }

  input(value)
  {
    this.text=value;
  }

}
