import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';


@Component({
  selector: 'app-test3',
  templateUrl: './test3.component.html',
  styleUrls: ['./test3.component.css']
})
export class Test3Component implements OnInit {
  color='white';

  public colors = ["red","purple","green","blue"];

  @Input('parentData') public text;

  @Output() public childEvent = new EventEmitter();
  
  constructor() { }

  ngOnInit() {
  }

  fireEvent()
  {
    this.childEvent.emit("Child to Parent");
  }

}
