export interface ICurrency
{
    id : number,
    totalCalculatedAmount : number
}