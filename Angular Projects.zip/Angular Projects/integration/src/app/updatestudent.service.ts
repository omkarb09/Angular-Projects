import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';




@Injectable({
  providedIn: 'root'
})
export class UpdatestudentService {
  
  _url='http://localhost:8080/RestDemo/update';
  constructor(private _http: HttpClient) { }

 

  register(userData: Object) {
    return this._http.put<any>(this._url, userData); 
  }
}

