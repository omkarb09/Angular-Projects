import { Component } from '@angular/core';
import { FormGroup, FormControl, Validator } from '@angular/forms';
import { AddstudentService } from './addstudent.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  constructor(private _addstudent: AddstudentService) {}
  addstudent = new FormGroup({
    name: new FormControl(''),
    tech: new FormControl(''),
  });

  onSubmit(){
    console.log(this.addstudent.value);
    this._addstudent.register(this.addstudent.value)
     .subscribe(
      response => console.log('Added', response)
    );
  }
}
