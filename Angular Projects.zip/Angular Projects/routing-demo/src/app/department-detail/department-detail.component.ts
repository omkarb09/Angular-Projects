import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-department-detail',
  template: `
    <p>
      department-detail works!
    </p>
  `,
  styles: []
})
export class DepartmentDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
