import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { EmployeesService } from '../employees.service';


@Component({
  selector: 'app-test',
  template:`
  <h1>Employee details</h1>
  <ul *ngFor="let detail of employees">
  <li> {{detail.id}} - {{detail.name}} </li>
  
  </ul>

  
   `,
  styles: [`

  `]
})
export class TestComponent implements OnInit {
  employees=[];
  constructor(private _employeeService: EmployeesService) { }
  ngOnInit() {
    this._employeeService.getEmployee().subscribe(data => this.employees = data);
  }
 

}
